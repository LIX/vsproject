﻿namespace BreakRack
{
	partial class Form1
	{
		/// <summary>
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows 窗体设计器生成的代码

		/// <summary>
		/// 设计器支持所需的方法 - 不要修改
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
			System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
			System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
			System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.textBox_CANID = new System.Windows.Forms.TextBox();
			this.textBox_pulse_1 = new System.Windows.Forms.TextBox();
			this.textBox_pulse_2 = new System.Windows.Forms.TextBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.button_release = new System.Windows.Forms.Button();
			this.button_brake = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.label58 = new System.Windows.Forms.Label();
			this.label53 = new System.Windows.Forms.Label();
			this.button_OilDrainage = new System.Windows.Forms.Button();
			this.label11 = new System.Windows.Forms.Label();
			this.textBox_BrkPedl = new System.Windows.Forms.TextBox();
			this.button_BrkPedl = new System.Windows.Forms.Button();
			this.textBox_wheel_pressure = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.textBox_master_pressure = new System.Windows.Forms.TextBox();
			this.comboBox_serialport = new System.Windows.Forms.ComboBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.label_OilDutyCycleBack = new System.Windows.Forms.Label();
			this.button_setOilPumpCycle2 = new System.Windows.Forms.Button();
			this.button_setOilPumpCycle = new System.Windows.Forms.Button();
			this.textBox_OilPumpDutycycle2 = new System.Windows.Forms.TextBox();
			this.textBox_OilPumpDutycycle = new System.Windows.Forms.TextBox();
			this.button_disableDem = new System.Windows.Forms.Button();
			this.button_settorque = new System.Windows.Forms.Button();
			this.button_enableDem = new System.Windows.Forms.Button();
			this.button_setspeed = new System.Windows.Forms.Button();
			this.textBox_targettorque = new System.Windows.Forms.TextBox();
			this.textBox_targetspeed = new System.Windows.Forms.TextBox();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.groupBox10 = new System.Windows.Forms.GroupBox();
			this.textBox_faultcode1 = new System.Windows.Forms.TextBox();
			this.textBox_faultcode4 = new System.Windows.Forms.TextBox();
			this.textBox_faultcode3 = new System.Windows.Forms.TextBox();
			this.label36 = new System.Windows.Forms.Label();
			this.textBox_faultcode2 = new System.Windows.Forms.TextBox();
			this.label37 = new System.Windows.Forms.Label();
			this.label38 = new System.Windows.Forms.Label();
			this.label39 = new System.Windows.Forms.Label();
			this.label40 = new System.Windows.Forms.Label();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.textBox_MaxSpeedAtCurTor = new System.Windows.Forms.TextBox();
			this.textBox_torqueback = new System.Windows.Forms.TextBox();
			this.textBox_MaxNegTorque = new System.Windows.Forms.TextBox();
			this.textBox_MaxPosTorque = new System.Windows.Forms.TextBox();
			this.textBox_speedback = new System.Windows.Forms.TextBox();
			this.label25 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label30 = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.textBox_faultlevel = new System.Windows.Forms.TextBox();
			this.textBox_motormode = new System.Windows.Forms.TextBox();
			this.label20 = new System.Windows.Forms.Label();
			this.textBox_motorstate = new System.Windows.Forms.TextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label_torquevalid = new System.Windows.Forms.Label();
			this.label_InitDone = new System.Windows.Forms.Label();
			this.label28 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.label_speedvalid = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label_HVReady = new System.Windows.Forms.Label();
			this.label_HVOK = new System.Windows.Forms.Label();
			this.label_motorenable = new System.Windows.Forms.Label();
			this.groupBox9 = new System.Windows.Forms.GroupBox();
			this.textBox_motortemp = new System.Windows.Forms.TextBox();
			this.textBox_FirmwareVersion = new System.Windows.Forms.TextBox();
			this.textBox_coldOiltemp = new System.Windows.Forms.TextBox();
			this.textBox_IGBTtemp = new System.Windows.Forms.TextBox();
			this.label31 = new System.Windows.Forms.Label();
			this.textBox_controllertemp = new System.Windows.Forms.TextBox();
			this.label32 = new System.Windows.Forms.Label();
			this.label34 = new System.Windows.Forms.Label();
			this.label33 = new System.Windows.Forms.Label();
			this.label35 = new System.Windows.Forms.Label();
			this.groupBox8 = new System.Windows.Forms.GroupBox();
			this.textBox_IdCurrent = new System.Windows.Forms.TextBox();
			this.textBox_PhaseCurrent = new System.Windows.Forms.TextBox();
			this.textBox_BusVoltage = new System.Windows.Forms.TextBox();
			this.textBox_BusCurrent = new System.Windows.Forms.TextBox();
			this.textBox_IqCurrent = new System.Windows.Forms.TextBox();
			this.label27 = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.comboBox_frametype = new System.Windows.Forms.ComboBox();
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.textBox_DCDCID = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.button_serial = new System.Windows.Forms.Button();
			this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
			this.groupBox11 = new System.Windows.Forms.GroupBox();
			this.textBox_DCState = new System.Windows.Forms.TextBox();
			this.textBox_DCInV = new System.Windows.Forms.TextBox();
			this.textBox_DCTemp = new System.Windows.Forms.TextBox();
			this.textBox_DCOutV = new System.Windows.Forms.TextBox();
			this.textBox_DCOutC = new System.Windows.Forms.TextBox();
			this.label47 = new System.Windows.Forms.Label();
			this.label46 = new System.Windows.Forms.Label();
			this.label45 = new System.Windows.Forms.Label();
			this.label_ST = new System.Windows.Forms.Label();
			this.label_InOV = new System.Windows.Forms.Label();
			this.label_COT = new System.Windows.Forms.Label();
			this.label_FE = new System.Windows.Forms.Label();
			this.label_OutLV = new System.Windows.Forms.Label();
			this.label_OutSC = new System.Windows.Forms.Label();
			this.label_OutOV = new System.Windows.Forms.Label();
			this.label_InLV = new System.Windows.Forms.Label();
			this.label_OutOC = new System.Windows.Forms.Label();
			this.label_OT = new System.Windows.Forms.Label();
			this.label44 = new System.Windows.Forms.Label();
			this.label52 = new System.Windows.Forms.Label();
			this.label51 = new System.Windows.Forms.Label();
			this.label50 = new System.Windows.Forms.Label();
			this.label49 = new System.Windows.Forms.Label();
			this.label48 = new System.Windows.Forms.Label();
			this.label43 = new System.Windows.Forms.Label();
			this.label42 = new System.Windows.Forms.Label();
			this.label41 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
			this.groupBox12 = new System.Windows.Forms.GroupBox();
			this.label60 = new System.Windows.Forms.Label();
			this.textBox_brakeinteval = new System.Windows.Forms.TextBox();
			this.label59 = new System.Windows.Forms.Label();
			this.textBox_executedCounter = new System.Windows.Forms.TextBox();
			this.textBox_totalCounter = new System.Windows.Forms.TextBox();
			this.label54 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.button_scheduled = new System.Windows.Forms.Button();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.button4 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.richTextBox3 = new System.Windows.Forms.RichTextBox();
			this.button2 = new System.Windows.Forms.Button();
			this.label57 = new System.Windows.Forms.Label();
			this.richTextBox2 = new System.Windows.Forms.RichTextBox();
			this.label_framespeed = new System.Windows.Forms.Label();
			this.label56 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.label_frameCount = new System.Windows.Forms.Label();
			this.label55 = new System.Windows.Forms.Label();
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.listView1 = new System.Windows.Forms.ListView();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox10.SuspendLayout();
			this.groupBox7.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.groupBox9.SuspendLayout();
			this.groupBox8.SuspendLayout();
			this.groupBox6.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
			this.groupBox11.SuspendLayout();
			this.groupBox12.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(24, 25);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(52, 15);
			this.label2.TabIndex = 0;
			this.label2.Text = "串口号";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(258, 25);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(77, 15);
			this.label3.TabIndex = 3;
			this.label3.Text = "电机ID:0x";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(663, 25);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(52, 15);
			this.label4.TabIndex = 0;
			this.label4.Text = "帧类型";
			// 
			// textBox_CANID
			// 
			this.textBox_CANID.Location = new System.Drawing.Point(338, 20);
			this.textBox_CANID.Name = "textBox_CANID";
			this.textBox_CANID.Size = new System.Drawing.Size(66, 25);
			this.textBox_CANID.TabIndex = 2;
			// 
			// textBox_pulse_1
			// 
			this.textBox_pulse_1.Location = new System.Drawing.Point(12, 23);
			this.textBox_pulse_1.Name = "textBox_pulse_1";
			this.textBox_pulse_1.Size = new System.Drawing.Size(51, 25);
			this.textBox_pulse_1.TabIndex = 0;
			this.textBox_pulse_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.toolTip1.SetToolTip(this.textBox_pulse_1, "-32768到32767");
			this.textBox_pulse_1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_pulse_1_KeyDown);
			// 
			// textBox_pulse_2
			// 
			this.textBox_pulse_2.Location = new System.Drawing.Point(12, 61);
			this.textBox_pulse_2.Name = "textBox_pulse_2";
			this.textBox_pulse_2.Size = new System.Drawing.Size(51, 25);
			this.textBox_pulse_2.TabIndex = 2;
			this.textBox_pulse_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.toolTip1.SetToolTip(this.textBox_pulse_2, "-32768到32767");
			this.textBox_pulse_2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_pulse_2_KeyDown);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.button_release);
			this.groupBox1.Controls.Add(this.button_brake);
			this.groupBox1.Controls.Add(this.textBox_pulse_2);
			this.groupBox1.Controls.Add(this.textBox_pulse_1);
			this.groupBox1.Location = new System.Drawing.Point(14, 81);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(149, 100);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "机械刹";
			// 
			// button_release
			// 
			this.button_release.Location = new System.Drawing.Point(78, 60);
			this.button_release.Name = "button_release";
			this.button_release.Size = new System.Drawing.Size(54, 27);
			this.button_release.TabIndex = 3;
			this.button_release.Text = "解除";
			this.button_release.UseVisualStyleBackColor = true;
			this.button_release.Click += new System.EventHandler(this.button_release_Click);
			// 
			// button_brake
			// 
			this.button_brake.Location = new System.Drawing.Point(78, 22);
			this.button_brake.Name = "button_brake";
			this.button_brake.Size = new System.Drawing.Size(54, 27);
			this.button_brake.TabIndex = 1;
			this.button_brake.Text = "刹车";
			this.button_brake.UseVisualStyleBackColor = true;
			this.button_brake.Click += new System.EventHandler(this.button_brake_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.label58);
			this.groupBox2.Controls.Add(this.label53);
			this.groupBox2.Controls.Add(this.button_OilDrainage);
			this.groupBox2.Controls.Add(this.label11);
			this.groupBox2.Controls.Add(this.textBox_BrkPedl);
			this.groupBox2.Controls.Add(this.button_BrkPedl);
			this.groupBox2.Controls.Add(this.textBox_wheel_pressure);
			this.groupBox2.Controls.Add(this.label8);
			this.groupBox2.Controls.Add(this.label9);
			this.groupBox2.Controls.Add(this.textBox_master_pressure);
			this.groupBox2.Location = new System.Drawing.Point(178, 81);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(323, 100);
			this.groupBox2.TabIndex = 2;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "液压刹";
			// 
			// label58
			// 
			this.label58.AutoSize = true;
			this.label58.Location = new System.Drawing.Point(13, 66);
			this.label58.Name = "label58";
			this.label58.Size = new System.Drawing.Size(67, 15);
			this.label58.TabIndex = 33;
			this.label58.Text = "系统时间";
			// 
			// label53
			// 
			this.label53.AutoSize = true;
			this.label53.Location = new System.Drawing.Point(111, 28);
			this.label53.Name = "label53";
			this.label53.Size = new System.Drawing.Size(0, 15);
			this.label53.TabIndex = 32;
			// 
			// button_OilDrainage
			// 
			this.button_OilDrainage.Location = new System.Drawing.Point(108, 61);
			this.button_OilDrainage.Name = "button_OilDrainage";
			this.button_OilDrainage.Size = new System.Drawing.Size(60, 27);
			this.button_OilDrainage.TabIndex = 31;
			this.button_OilDrainage.Text = "解除";
			this.button_OilDrainage.UseVisualStyleBackColor = true;
			this.button_OilDrainage.Click += new System.EventHandler(this.button_OilDrainage_Click);
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(86, 29);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(15, 15);
			this.label11.TabIndex = 4;
			this.label11.Text = "%";
			// 
			// textBox_BrkPedl
			// 
			this.textBox_BrkPedl.Location = new System.Drawing.Point(16, 25);
			this.textBox_BrkPedl.Name = "textBox_BrkPedl";
			this.textBox_BrkPedl.Size = new System.Drawing.Size(69, 25);
			this.textBox_BrkPedl.TabIndex = 2;
			this.textBox_BrkPedl.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.toolTip1.SetToolTip(this.textBox_BrkPedl, "0到100");
			this.textBox_BrkPedl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_BrkPedl_KeyDown);
			// 
			// button_BrkPedl
			// 
			this.button_BrkPedl.Location = new System.Drawing.Point(108, 25);
			this.button_BrkPedl.Name = "button_BrkPedl";
			this.button_BrkPedl.Size = new System.Drawing.Size(60, 27);
			this.button_BrkPedl.TabIndex = 3;
			this.button_BrkPedl.Text = "刹车";
			this.button_BrkPedl.UseVisualStyleBackColor = true;
			this.button_BrkPedl.Click += new System.EventHandler(this.button_BrkPedl_Click);
			// 
			// textBox_wheel_pressure
			// 
			this.textBox_wheel_pressure.Location = new System.Drawing.Point(228, 62);
			this.textBox_wheel_pressure.Name = "textBox_wheel_pressure";
			this.textBox_wheel_pressure.ReadOnly = true;
			this.textBox_wheel_pressure.Size = new System.Drawing.Size(75, 25);
			this.textBox_wheel_pressure.TabIndex = 30;
			this.textBox_wheel_pressure.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(187, 31);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(37, 15);
			this.label8.TabIndex = 0;
			this.label8.Text = "主缸";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(187, 67);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(37, 15);
			this.label9.TabIndex = 0;
			this.label9.Text = "轮缸";
			// 
			// textBox_master_pressure
			// 
			this.textBox_master_pressure.Location = new System.Drawing.Point(227, 26);
			this.textBox_master_pressure.Name = "textBox_master_pressure";
			this.textBox_master_pressure.ReadOnly = true;
			this.textBox_master_pressure.Size = new System.Drawing.Size(76, 25);
			this.textBox_master_pressure.TabIndex = 3;
			this.textBox_master_pressure.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// comboBox_serialport
			// 
			this.comboBox_serialport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_serialport.FormattingEnabled = true;
			this.comboBox_serialport.Location = new System.Drawing.Point(80, 21);
			this.comboBox_serialport.Name = "comboBox_serialport";
			this.comboBox_serialport.Size = new System.Drawing.Size(71, 23);
			this.comboBox_serialport.TabIndex = 0;
			this.comboBox_serialport.Click += new System.EventHandler(this.comboBox_serialport_Click);
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.label_OilDutyCycleBack);
			this.groupBox3.Controls.Add(this.button_setOilPumpCycle2);
			this.groupBox3.Controls.Add(this.button_setOilPumpCycle);
			this.groupBox3.Controls.Add(this.textBox_OilPumpDutycycle2);
			this.groupBox3.Controls.Add(this.textBox_OilPumpDutycycle);
			this.groupBox3.Controls.Add(this.button_disableDem);
			this.groupBox3.Controls.Add(this.button_settorque);
			this.groupBox3.Controls.Add(this.button_enableDem);
			this.groupBox3.Controls.Add(this.button_setspeed);
			this.groupBox3.Controls.Add(this.textBox_targettorque);
			this.groupBox3.Controls.Add(this.textBox_targetspeed);
			this.groupBox3.Location = new System.Drawing.Point(47, 193);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(790, 57);
			this.groupBox3.TabIndex = 3;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "控制";
			// 
			// label_OilDutyCycleBack
			// 
			this.label_OilDutyCycleBack.AutoSize = true;
			this.label_OilDutyCycleBack.Location = new System.Drawing.Point(277, 25);
			this.label_OilDutyCycleBack.Name = "label_OilDutyCycleBack";
			this.label_OilDutyCycleBack.Size = new System.Drawing.Size(52, 15);
			this.label_OilDutyCycleBack.TabIndex = 5;
			this.label_OilDutyCycleBack.Text = "占空比";
			// 
			// button_setOilPumpCycle2
			// 
			this.button_setOilPumpCycle2.Location = new System.Drawing.Point(213, 22);
			this.button_setOilPumpCycle2.Name = "button_setOilPumpCycle2";
			this.button_setOilPumpCycle2.Size = new System.Drawing.Size(54, 27);
			this.button_setOilPumpCycle2.TabIndex = 10;
			this.button_setOilPumpCycle2.Text = "流量2";
			this.button_setOilPumpCycle2.UseVisualStyleBackColor = true;
			this.button_setOilPumpCycle2.Click += new System.EventHandler(this.button_setOilPumpCycle2_Click);
			// 
			// button_setOilPumpCycle
			// 
			this.button_setOilPumpCycle.Location = new System.Drawing.Point(83, 22);
			this.button_setOilPumpCycle.Name = "button_setOilPumpCycle";
			this.button_setOilPumpCycle.Size = new System.Drawing.Size(54, 27);
			this.button_setOilPumpCycle.TabIndex = 10;
			this.button_setOilPumpCycle.Text = "流量1";
			this.button_setOilPumpCycle.UseVisualStyleBackColor = true;
			this.button_setOilPumpCycle.Click += new System.EventHandler(this.button_setOilPumpCycle_Click);
			// 
			// textBox_OilPumpDutycycle2
			// 
			this.textBox_OilPumpDutycycle2.Location = new System.Drawing.Point(147, 23);
			this.textBox_OilPumpDutycycle2.Name = "textBox_OilPumpDutycycle2";
			this.textBox_OilPumpDutycycle2.Size = new System.Drawing.Size(56, 25);
			this.textBox_OilPumpDutycycle2.TabIndex = 9;
			this.textBox_OilPumpDutycycle2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox_OilPumpDutycycle2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_OilPumpDutycycle2_KeyDown);
			// 
			// textBox_OilPumpDutycycle
			// 
			this.textBox_OilPumpDutycycle.Location = new System.Drawing.Point(16, 23);
			this.textBox_OilPumpDutycycle.Name = "textBox_OilPumpDutycycle";
			this.textBox_OilPumpDutycycle.Size = new System.Drawing.Size(56, 25);
			this.textBox_OilPumpDutycycle.TabIndex = 9;
			this.textBox_OilPumpDutycycle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox_OilPumpDutycycle.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_OilPumpDutycycle_KeyDown);
			// 
			// button_disableDem
			// 
			this.button_disableDem.Location = new System.Drawing.Point(415, 20);
			this.button_disableDem.Name = "button_disableDem";
			this.button_disableDem.Size = new System.Drawing.Size(54, 27);
			this.button_disableDem.TabIndex = 8;
			this.button_disableDem.Text = "关闭";
			this.button_disableDem.UseVisualStyleBackColor = true;
			this.button_disableDem.Click += new System.EventHandler(this.button_disableDem_Click);
			// 
			// button_settorque
			// 
			this.button_settorque.Location = new System.Drawing.Point(719, 19);
			this.button_settorque.Name = "button_settorque";
			this.button_settorque.Size = new System.Drawing.Size(54, 27);
			this.button_settorque.TabIndex = 6;
			this.button_settorque.Text = "转矩";
			this.button_settorque.UseVisualStyleBackColor = true;
			this.button_settorque.Click += new System.EventHandler(this.button_settorque_Click);
			// 
			// button_enableDem
			// 
			this.button_enableDem.Location = new System.Drawing.Point(354, 19);
			this.button_enableDem.Name = "button_enableDem";
			this.button_enableDem.Size = new System.Drawing.Size(54, 27);
			this.button_enableDem.TabIndex = 2;
			this.button_enableDem.Text = "使能";
			this.button_enableDem.UseVisualStyleBackColor = true;
			this.button_enableDem.Click += new System.EventHandler(this.button_enableDem_Click);
			// 
			// button_setspeed
			// 
			this.button_setspeed.Location = new System.Drawing.Point(572, 19);
			this.button_setspeed.Name = "button_setspeed";
			this.button_setspeed.Size = new System.Drawing.Size(54, 27);
			this.button_setspeed.TabIndex = 4;
			this.button_setspeed.Text = "转速";
			this.button_setspeed.UseVisualStyleBackColor = true;
			this.button_setspeed.Click += new System.EventHandler(this.button_setspeed_Click);
			// 
			// textBox_targettorque
			// 
			this.textBox_targettorque.Location = new System.Drawing.Point(646, 20);
			this.textBox_targettorque.Name = "textBox_targettorque";
			this.textBox_targettorque.Size = new System.Drawing.Size(67, 25);
			this.textBox_targettorque.TabIndex = 5;
			this.textBox_targettorque.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.toolTip1.SetToolTip(this.textBox_targettorque, "-512到511");
			this.textBox_targettorque.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_targettorque_KeyDown);
			// 
			// textBox_targetspeed
			// 
			this.textBox_targetspeed.Location = new System.Drawing.Point(493, 20);
			this.textBox_targetspeed.Name = "textBox_targetspeed";
			this.textBox_targetspeed.Size = new System.Drawing.Size(73, 25);
			this.textBox_targetspeed.TabIndex = 3;
			this.textBox_targetspeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.toolTip1.SetToolTip(this.textBox_targetspeed, "-32768到32767");
			this.textBox_targetspeed.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_targetspeed_KeyDown);
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.groupBox10);
			this.groupBox4.Controls.Add(this.groupBox7);
			this.groupBox4.Controls.Add(this.groupBox5);
			this.groupBox4.Controls.Add(this.groupBox9);
			this.groupBox4.Controls.Add(this.groupBox8);
			this.groupBox4.Location = new System.Drawing.Point(12, 265);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(853, 369);
			this.groupBox4.TabIndex = 5;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "电机状态";
			// 
			// groupBox10
			// 
			this.groupBox10.Controls.Add(this.textBox_faultcode1);
			this.groupBox10.Controls.Add(this.textBox_faultcode4);
			this.groupBox10.Controls.Add(this.textBox_faultcode3);
			this.groupBox10.Controls.Add(this.label36);
			this.groupBox10.Controls.Add(this.textBox_faultcode2);
			this.groupBox10.Controls.Add(this.label37);
			this.groupBox10.Controls.Add(this.label38);
			this.groupBox10.Controls.Add(this.label39);
			this.groupBox10.Controls.Add(this.label40);
			this.groupBox10.Location = new System.Drawing.Point(657, 131);
			this.groupBox10.Name = "groupBox10";
			this.groupBox10.Size = new System.Drawing.Size(182, 219);
			this.groupBox10.TabIndex = 4;
			this.groupBox10.TabStop = false;
			this.groupBox10.Text = "0x6x";
			// 
			// textBox_faultcode1
			// 
			this.textBox_faultcode1.Location = new System.Drawing.Point(82, 30);
			this.textBox_faultcode1.Name = "textBox_faultcode1";
			this.textBox_faultcode1.ReadOnly = true;
			this.textBox_faultcode1.Size = new System.Drawing.Size(84, 25);
			this.textBox_faultcode1.TabIndex = 1;
			this.textBox_faultcode1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_faultcode4
			// 
			this.textBox_faultcode4.Location = new System.Drawing.Point(82, 171);
			this.textBox_faultcode4.Name = "textBox_faultcode4";
			this.textBox_faultcode4.ReadOnly = true;
			this.textBox_faultcode4.Size = new System.Drawing.Size(84, 25);
			this.textBox_faultcode4.TabIndex = 1;
			this.textBox_faultcode4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_faultcode3
			// 
			this.textBox_faultcode3.Location = new System.Drawing.Point(82, 125);
			this.textBox_faultcode3.Name = "textBox_faultcode3";
			this.textBox_faultcode3.ReadOnly = true;
			this.textBox_faultcode3.Size = new System.Drawing.Size(84, 25);
			this.textBox_faultcode3.TabIndex = 1;
			this.textBox_faultcode3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label36
			// 
			this.label36.AutoSize = true;
			this.label36.Location = new System.Drawing.Point(15, 35);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(60, 15);
			this.label36.TabIndex = 0;
			this.label36.Text = "故障码1";
			// 
			// textBox_faultcode2
			// 
			this.textBox_faultcode2.Location = new System.Drawing.Point(82, 77);
			this.textBox_faultcode2.Name = "textBox_faultcode2";
			this.textBox_faultcode2.ReadOnly = true;
			this.textBox_faultcode2.Size = new System.Drawing.Size(84, 25);
			this.textBox_faultcode2.TabIndex = 1;
			this.textBox_faultcode2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label37
			// 
			this.label37.AutoSize = true;
			this.label37.Location = new System.Drawing.Point(637, 23);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(0, 15);
			this.label37.TabIndex = 0;
			// 
			// label38
			// 
			this.label38.AutoSize = true;
			this.label38.Location = new System.Drawing.Point(15, 176);
			this.label38.Name = "label38";
			this.label38.Size = new System.Drawing.Size(60, 15);
			this.label38.TabIndex = 0;
			this.label38.Text = "故障码4";
			// 
			// label39
			// 
			this.label39.AutoSize = true;
			this.label39.Location = new System.Drawing.Point(15, 130);
			this.label39.Name = "label39";
			this.label39.Size = new System.Drawing.Size(60, 15);
			this.label39.TabIndex = 0;
			this.label39.Text = "故障码3";
			// 
			// label40
			// 
			this.label40.AutoSize = true;
			this.label40.Location = new System.Drawing.Point(15, 82);
			this.label40.Name = "label40";
			this.label40.Size = new System.Drawing.Size(60, 15);
			this.label40.TabIndex = 0;
			this.label40.Text = "故障码2";
			// 
			// groupBox7
			// 
			this.groupBox7.Controls.Add(this.textBox_MaxSpeedAtCurTor);
			this.groupBox7.Controls.Add(this.textBox_torqueback);
			this.groupBox7.Controls.Add(this.textBox_MaxNegTorque);
			this.groupBox7.Controls.Add(this.textBox_MaxPosTorque);
			this.groupBox7.Controls.Add(this.textBox_speedback);
			this.groupBox7.Controls.Add(this.label25);
			this.groupBox7.Controls.Add(this.label22);
			this.groupBox7.Controls.Add(this.label21);
			this.groupBox7.Controls.Add(this.label30);
			this.groupBox7.Controls.Add(this.label29);
			this.groupBox7.Location = new System.Drawing.Point(14, 131);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new System.Drawing.Size(189, 219);
			this.groupBox7.TabIndex = 3;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "0x2x";
			// 
			// textBox_MaxSpeedAtCurTor
			// 
			this.textBox_MaxSpeedAtCurTor.Location = new System.Drawing.Point(81, 175);
			this.textBox_MaxSpeedAtCurTor.Name = "textBox_MaxSpeedAtCurTor";
			this.textBox_MaxSpeedAtCurTor.ReadOnly = true;
			this.textBox_MaxSpeedAtCurTor.Size = new System.Drawing.Size(91, 25);
			this.textBox_MaxSpeedAtCurTor.TabIndex = 1;
			this.textBox_MaxSpeedAtCurTor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_torqueback
			// 
			this.textBox_torqueback.Location = new System.Drawing.Point(81, 61);
			this.textBox_torqueback.Name = "textBox_torqueback";
			this.textBox_torqueback.ReadOnly = true;
			this.textBox_torqueback.Size = new System.Drawing.Size(91, 25);
			this.textBox_torqueback.TabIndex = 1;
			this.textBox_torqueback.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_MaxNegTorque
			// 
			this.textBox_MaxNegTorque.Location = new System.Drawing.Point(81, 137);
			this.textBox_MaxNegTorque.Name = "textBox_MaxNegTorque";
			this.textBox_MaxNegTorque.ReadOnly = true;
			this.textBox_MaxNegTorque.Size = new System.Drawing.Size(91, 25);
			this.textBox_MaxNegTorque.TabIndex = 1;
			this.textBox_MaxNegTorque.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_MaxPosTorque
			// 
			this.textBox_MaxPosTorque.Location = new System.Drawing.Point(81, 99);
			this.textBox_MaxPosTorque.Name = "textBox_MaxPosTorque";
			this.textBox_MaxPosTorque.ReadOnly = true;
			this.textBox_MaxPosTorque.Size = new System.Drawing.Size(91, 25);
			this.textBox_MaxPosTorque.TabIndex = 1;
			this.textBox_MaxPosTorque.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_speedback
			// 
			this.textBox_speedback.Location = new System.Drawing.Point(81, 23);
			this.textBox_speedback.Name = "textBox_speedback";
			this.textBox_speedback.ReadOnly = true;
			this.textBox_speedback.Size = new System.Drawing.Size(91, 25);
			this.textBox_speedback.TabIndex = 1;
			this.textBox_speedback.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(6, 182);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(71, 15);
			this.label25.TabIndex = 0;
			this.label25.Text = "MaxSpeed";
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(40, 65);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(37, 15);
			this.label22.TabIndex = 0;
			this.label22.Text = "转矩";
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(40, 28);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(37, 15);
			this.label21.TabIndex = 0;
			this.label21.Text = "转速";
			// 
			// label30
			// 
			this.label30.AutoSize = true;
			this.label30.Location = new System.Drawing.Point(30, 139);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(47, 15);
			this.label30.TabIndex = 0;
			this.label30.Text = "MaxNT";
			// 
			// label29
			// 
			this.label29.AutoSize = true;
			this.label29.Location = new System.Drawing.Point(30, 101);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(47, 15);
			this.label29.TabIndex = 0;
			this.label29.Text = "MaxPT";
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.Add(this.label1);
			this.groupBox5.Controls.Add(this.textBox_faultlevel);
			this.groupBox5.Controls.Add(this.textBox_motormode);
			this.groupBox5.Controls.Add(this.label20);
			this.groupBox5.Controls.Add(this.textBox_motorstate);
			this.groupBox5.Controls.Add(this.label18);
			this.groupBox5.Controls.Add(this.label7);
			this.groupBox5.Controls.Add(this.label_torquevalid);
			this.groupBox5.Controls.Add(this.label_InitDone);
			this.groupBox5.Controls.Add(this.label28);
			this.groupBox5.Controls.Add(this.label24);
			this.groupBox5.Controls.Add(this.label6);
			this.groupBox5.Controls.Add(this.label23);
			this.groupBox5.Controls.Add(this.label_speedvalid);
			this.groupBox5.Controls.Add(this.label5);
			this.groupBox5.Controls.Add(this.label_HVReady);
			this.groupBox5.Controls.Add(this.label_HVOK);
			this.groupBox5.Controls.Add(this.label_motorenable);
			this.groupBox5.Location = new System.Drawing.Point(12, 24);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(827, 99);
			this.groupBox5.TabIndex = 2;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "0x3x";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(31, 27);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(82, 15);
			this.label1.TabIndex = 0;
			this.label1.Text = "初始化完成";
			// 
			// textBox_faultlevel
			// 
			this.textBox_faultlevel.Location = new System.Drawing.Point(631, 57);
			this.textBox_faultlevel.Name = "textBox_faultlevel";
			this.textBox_faultlevel.ReadOnly = true;
			this.textBox_faultlevel.Size = new System.Drawing.Size(74, 25);
			this.textBox_faultlevel.TabIndex = 1;
			this.textBox_faultlevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_motormode
			// 
			this.textBox_motormode.Location = new System.Drawing.Point(381, 57);
			this.textBox_motormode.Name = "textBox_motormode";
			this.textBox_motormode.ReadOnly = true;
			this.textBox_motormode.Size = new System.Drawing.Size(111, 25);
			this.textBox_motormode.TabIndex = 1;
			this.textBox_motormode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(694, 27);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(67, 15);
			this.label20.TabIndex = 0;
			this.label20.Text = "转矩有效";
			// 
			// textBox_motorstate
			// 
			this.textBox_motorstate.Location = new System.Drawing.Point(127, 57);
			this.textBox_motorstate.Name = "textBox_motorstate";
			this.textBox_motorstate.ReadOnly = true;
			this.textBox_motorstate.Size = new System.Drawing.Size(85, 25);
			this.textBox_motorstate.TabIndex = 1;
			this.textBox_motorstate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(575, 27);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(67, 15);
			this.label18.TabIndex = 0;
			this.label18.Text = "转速有效";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(433, 28);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(82, 15);
			this.label7.TabIndex = 0;
			this.label7.Text = "下强电就绪";
			// 
			// label_torquevalid
			// 
			this.label_torquevalid.AutoSize = true;
			this.label_torquevalid.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_torquevalid.ForeColor = System.Drawing.Color.DimGray;
			this.label_torquevalid.Location = new System.Drawing.Point(755, 20);
			this.label_torquevalid.Name = "label_torquevalid";
			this.label_torquevalid.Size = new System.Drawing.Size(40, 28);
			this.label_torquevalid.TabIndex = 0;
			this.label_torquevalid.Text = "●";
			// 
			// label_InitDone
			// 
			this.label_InitDone.AutoSize = true;
			this.label_InitDone.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_InitDone.ForeColor = System.Drawing.Color.DimGray;
			this.label_InitDone.Location = new System.Drawing.Point(110, 20);
			this.label_InitDone.Name = "label_InitDone";
			this.label_InitDone.Size = new System.Drawing.Size(40, 28);
			this.label_InitDone.TabIndex = 0;
			this.label_InitDone.Text = "●";
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(560, 62);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(67, 15);
			this.label28.TabIndex = 0;
			this.label28.Text = "故障等级";
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(311, 62);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(67, 15);
			this.label24.TabIndex = 0;
			this.label24.Text = "工作模式";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(300, 27);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(67, 15);
			this.label6.TabIndex = 0;
			this.label6.Text = "系统使能";
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(56, 62);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(67, 15);
			this.label23.TabIndex = 0;
			this.label23.Text = "电机状态";
			// 
			// label_speedvalid
			// 
			this.label_speedvalid.AutoSize = true;
			this.label_speedvalid.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_speedvalid.ForeColor = System.Drawing.Color.DimGray;
			this.label_speedvalid.Location = new System.Drawing.Point(636, 20);
			this.label_speedvalid.Name = "label_speedvalid";
			this.label_speedvalid.Size = new System.Drawing.Size(40, 28);
			this.label_speedvalid.TabIndex = 0;
			this.label_speedvalid.Text = "●";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(177, 27);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(67, 15);
			this.label5.TabIndex = 0;
			this.label5.Text = "高压正常";
			// 
			// label_HVReady
			// 
			this.label_HVReady.AutoSize = true;
			this.label_HVReady.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_HVReady.ForeColor = System.Drawing.Color.DimGray;
			this.label_HVReady.Location = new System.Drawing.Point(510, 21);
			this.label_HVReady.Name = "label_HVReady";
			this.label_HVReady.Size = new System.Drawing.Size(40, 28);
			this.label_HVReady.TabIndex = 0;
			this.label_HVReady.Text = "●";
			// 
			// label_HVOK
			// 
			this.label_HVOK.AutoSize = true;
			this.label_HVOK.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_HVOK.ForeColor = System.Drawing.Color.DimGray;
			this.label_HVOK.Location = new System.Drawing.Point(236, 20);
			this.label_HVOK.Name = "label_HVOK";
			this.label_HVOK.Size = new System.Drawing.Size(40, 28);
			this.label_HVOK.TabIndex = 0;
			this.label_HVOK.Text = "●";
			// 
			// label_motorenable
			// 
			this.label_motorenable.AutoSize = true;
			this.label_motorenable.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_motorenable.ForeColor = System.Drawing.Color.DimGray;
			this.label_motorenable.Location = new System.Drawing.Point(360, 20);
			this.label_motorenable.Name = "label_motorenable";
			this.label_motorenable.Size = new System.Drawing.Size(40, 28);
			this.label_motorenable.TabIndex = 0;
			this.label_motorenable.Text = "●";
			// 
			// groupBox9
			// 
			this.groupBox9.Controls.Add(this.textBox_motortemp);
			this.groupBox9.Controls.Add(this.textBox_FirmwareVersion);
			this.groupBox9.Controls.Add(this.textBox_coldOiltemp);
			this.groupBox9.Controls.Add(this.textBox_IGBTtemp);
			this.groupBox9.Controls.Add(this.label31);
			this.groupBox9.Controls.Add(this.textBox_controllertemp);
			this.groupBox9.Controls.Add(this.label32);
			this.groupBox9.Controls.Add(this.label34);
			this.groupBox9.Controls.Add(this.label33);
			this.groupBox9.Controls.Add(this.label35);
			this.groupBox9.Location = new System.Drawing.Point(426, 131);
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.Size = new System.Drawing.Size(213, 219);
			this.groupBox9.TabIndex = 4;
			this.groupBox9.TabStop = false;
			this.groupBox9.Text = "0x5x";
			// 
			// textBox_motortemp
			// 
			this.textBox_motortemp.Location = new System.Drawing.Point(102, 28);
			this.textBox_motortemp.Name = "textBox_motortemp";
			this.textBox_motortemp.ReadOnly = true;
			this.textBox_motortemp.Size = new System.Drawing.Size(84, 25);
			this.textBox_motortemp.TabIndex = 1;
			this.textBox_motortemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_FirmwareVersion
			// 
			this.textBox_FirmwareVersion.Location = new System.Drawing.Point(102, 172);
			this.textBox_FirmwareVersion.Name = "textBox_FirmwareVersion";
			this.textBox_FirmwareVersion.ReadOnly = true;
			this.textBox_FirmwareVersion.Size = new System.Drawing.Size(84, 25);
			this.textBox_FirmwareVersion.TabIndex = 1;
			this.textBox_FirmwareVersion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_coldOiltemp
			// 
			this.textBox_coldOiltemp.Location = new System.Drawing.Point(102, 65);
			this.textBox_coldOiltemp.Name = "textBox_coldOiltemp";
			this.textBox_coldOiltemp.ReadOnly = true;
			this.textBox_coldOiltemp.Size = new System.Drawing.Size(84, 25);
			this.textBox_coldOiltemp.TabIndex = 1;
			this.textBox_coldOiltemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_IGBTtemp
			// 
			this.textBox_IGBTtemp.Location = new System.Drawing.Point(102, 136);
			this.textBox_IGBTtemp.Name = "textBox_IGBTtemp";
			this.textBox_IGBTtemp.ReadOnly = true;
			this.textBox_IGBTtemp.Size = new System.Drawing.Size(84, 25);
			this.textBox_IGBTtemp.TabIndex = 1;
			this.textBox_IGBTtemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label31
			// 
			this.label31.AutoSize = true;
			this.label31.Location = new System.Drawing.Point(27, 33);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(67, 15);
			this.label31.TabIndex = 0;
			this.label31.Text = "电机温度";
			// 
			// textBox_controllertemp
			// 
			this.textBox_controllertemp.Location = new System.Drawing.Point(102, 100);
			this.textBox_controllertemp.Name = "textBox_controllertemp";
			this.textBox_controllertemp.ReadOnly = true;
			this.textBox_controllertemp.Size = new System.Drawing.Size(84, 25);
			this.textBox_controllertemp.TabIndex = 1;
			this.textBox_controllertemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label32
			// 
			this.label32.AutoSize = true;
			this.label32.Location = new System.Drawing.Point(27, 177);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(67, 15);
			this.label32.TabIndex = 0;
			this.label32.Text = "软件版本";
			// 
			// label34
			// 
			this.label34.AutoSize = true;
			this.label34.Location = new System.Drawing.Point(25, 141);
			this.label34.Name = "label34";
			this.label34.Size = new System.Drawing.Size(69, 15);
			this.label34.TabIndex = 0;
			this.label34.Text = "IGBT温度";
			// 
			// label33
			// 
			this.label33.AutoSize = true;
			this.label33.Location = new System.Drawing.Point(12, 70);
			this.label33.Name = "label33";
			this.label33.Size = new System.Drawing.Size(82, 15);
			this.label33.TabIndex = 0;
			this.label33.Text = "冷却油温度";
			// 
			// label35
			// 
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(12, 105);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(82, 15);
			this.label35.TabIndex = 0;
			this.label35.Text = "控制器温度";
			// 
			// groupBox8
			// 
			this.groupBox8.Controls.Add(this.textBox_IdCurrent);
			this.groupBox8.Controls.Add(this.textBox_PhaseCurrent);
			this.groupBox8.Controls.Add(this.textBox_BusVoltage);
			this.groupBox8.Controls.Add(this.textBox_BusCurrent);
			this.groupBox8.Controls.Add(this.textBox_IqCurrent);
			this.groupBox8.Controls.Add(this.label27);
			this.groupBox8.Controls.Add(this.label26);
			this.groupBox8.Controls.Add(this.label16);
			this.groupBox8.Controls.Add(this.label14);
			this.groupBox8.Controls.Add(this.label15);
			this.groupBox8.Location = new System.Drawing.Point(225, 131);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Size = new System.Drawing.Size(176, 219);
			this.groupBox8.TabIndex = 4;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "0x4x";
			// 
			// textBox_IdCurrent
			// 
			this.textBox_IdCurrent.Location = new System.Drawing.Point(93, 27);
			this.textBox_IdCurrent.Name = "textBox_IdCurrent";
			this.textBox_IdCurrent.ReadOnly = true;
			this.textBox_IdCurrent.Size = new System.Drawing.Size(63, 25);
			this.textBox_IdCurrent.TabIndex = 1;
			this.textBox_IdCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_PhaseCurrent
			// 
			this.textBox_PhaseCurrent.Location = new System.Drawing.Point(93, 175);
			this.textBox_PhaseCurrent.Name = "textBox_PhaseCurrent";
			this.textBox_PhaseCurrent.ReadOnly = true;
			this.textBox_PhaseCurrent.Size = new System.Drawing.Size(63, 25);
			this.textBox_PhaseCurrent.TabIndex = 1;
			this.textBox_PhaseCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_BusVoltage
			// 
			this.textBox_BusVoltage.Location = new System.Drawing.Point(93, 138);
			this.textBox_BusVoltage.Name = "textBox_BusVoltage";
			this.textBox_BusVoltage.ReadOnly = true;
			this.textBox_BusVoltage.Size = new System.Drawing.Size(63, 25);
			this.textBox_BusVoltage.TabIndex = 1;
			this.textBox_BusVoltage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_BusCurrent
			// 
			this.textBox_BusCurrent.Location = new System.Drawing.Point(93, 101);
			this.textBox_BusCurrent.Name = "textBox_BusCurrent";
			this.textBox_BusCurrent.ReadOnly = true;
			this.textBox_BusCurrent.Size = new System.Drawing.Size(63, 25);
			this.textBox_BusCurrent.TabIndex = 1;
			this.textBox_BusCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_IqCurrent
			// 
			this.textBox_IqCurrent.Location = new System.Drawing.Point(93, 64);
			this.textBox_IqCurrent.Name = "textBox_IqCurrent";
			this.textBox_IqCurrent.ReadOnly = true;
			this.textBox_IqCurrent.Size = new System.Drawing.Size(63, 25);
			this.textBox_IqCurrent.TabIndex = 1;
			this.textBox_IqCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(14, 180);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(67, 15);
			this.label27.TabIndex = 0;
			this.label27.Text = "相线电流";
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(14, 143);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(67, 15);
			this.label26.TabIndex = 0;
			this.label26.Text = "母线电压";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(14, 106);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(67, 15);
			this.label16.TabIndex = 0;
			this.label16.Text = "母线电流";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(28, 32);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(53, 15);
			this.label14.TabIndex = 0;
			this.label14.Text = "Id电流";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(28, 69);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(53, 15);
			this.label15.TabIndex = 0;
			this.label15.Text = "Iq电流";
			// 
			// comboBox_frametype
			// 
			this.comboBox_frametype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_frametype.FormattingEnabled = true;
			this.comboBox_frametype.Location = new System.Drawing.Point(720, 21);
			this.comboBox_frametype.Name = "comboBox_frametype";
			this.comboBox_frametype.Size = new System.Drawing.Size(87, 23);
			this.comboBox_frametype.TabIndex = 3;
			// 
			// groupBox6
			// 
			this.groupBox6.Controls.Add(this.textBox_DCDCID);
			this.groupBox6.Controls.Add(this.label12);
			this.groupBox6.Controls.Add(this.label3);
			this.groupBox6.Controls.Add(this.button_serial);
			this.groupBox6.Controls.Add(this.label2);
			this.groupBox6.Controls.Add(this.comboBox_frametype);
			this.groupBox6.Controls.Add(this.label4);
			this.groupBox6.Controls.Add(this.comboBox_serialport);
			this.groupBox6.Controls.Add(this.textBox_CANID);
			this.groupBox6.Location = new System.Drawing.Point(12, 12);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new System.Drawing.Size(853, 58);
			this.groupBox6.TabIndex = 0;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "基本设置";
			// 
			// textBox_DCDCID
			// 
			this.textBox_DCDCID.Location = new System.Drawing.Point(547, 21);
			this.textBox_DCDCID.Name = "textBox_DCDCID";
			this.textBox_DCDCID.Size = new System.Drawing.Size(72, 25);
			this.textBox_DCDCID.TabIndex = 4;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(450, 26);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(95, 15);
			this.label12.TabIndex = 3;
			this.label12.Text = "DC-DC ID:0x";
			// 
			// button_serial
			// 
			this.button_serial.Location = new System.Drawing.Point(169, 21);
			this.button_serial.Name = "button_serial";
			this.button_serial.Size = new System.Drawing.Size(54, 27);
			this.button_serial.TabIndex = 1;
			this.button_serial.Text = "打开";
			this.button_serial.UseVisualStyleBackColor = true;
			this.button_serial.Click += new System.EventHandler(this.button_serial_Click);
			// 
			// serialPort1
			// 
			this.serialPort1.ReceivedBytesThreshold = 512;
			this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
			// 
			// toolTip1
			// 
			this.toolTip1.AutomaticDelay = 50;
			this.toolTip1.AutoPopDelay = 5000;
			this.toolTip1.InitialDelay = 50;
			this.toolTip1.ReshowDelay = 10;
			// 
			// chart1
			// 
			chartArea1.AxisY.Interval = 2000D;
			chartArea1.AxisY2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.True;
			chartArea1.AxisY2.Interval = 20D;
			chartArea1.InnerPlotPosition.Auto = false;
			chartArea1.InnerPlotPosition.Height = 90F;
			chartArea1.InnerPlotPosition.Width = 70F;
			chartArea1.InnerPlotPosition.X = 11.15278F;
			chartArea1.InnerPlotPosition.Y = 10F;
			chartArea1.IsSameFontSizeForAllAxes = true;
			chartArea1.Name = "ChartArea1";
			chartArea2.AxisX.Interval = 20D;
			chartArea2.AxisY.Interval = 0.5D;
			chartArea2.AxisY2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
			chartArea2.InnerPlotPosition.Auto = false;
			chartArea2.InnerPlotPosition.Height = 82F;
			chartArea2.InnerPlotPosition.Width = 75F;
			chartArea2.InnerPlotPosition.X = 11F;
			chartArea2.InnerPlotPosition.Y = 18F;
			chartArea2.IsSameFontSizeForAllAxes = true;
			chartArea2.Name = "ChartArea2";
			this.chart1.ChartAreas.Add(chartArea1);
			this.chart1.ChartAreas.Add(chartArea2);
			this.chart1.Location = new System.Drawing.Point(11, 1);
			this.chart1.Name = "chart1";
			series1.ChartArea = "ChartArea1";
			series1.Name = "Series1";
			series2.ChartArea = "ChartArea1";
			series2.Name = "Series2";
			series2.YAxisType = System.Windows.Forms.DataVisualization.Charting.AxisType.Secondary;
			series3.ChartArea = "ChartArea2";
			series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
			series3.Name = "Series3";
			series4.ChartArea = "ChartArea2";
			series4.Name = "Series4";
			this.chart1.Series.Add(series1);
			this.chart1.Series.Add(series2);
			this.chart1.Series.Add(series3);
			this.chart1.Series.Add(series4);
			this.chart1.Size = new System.Drawing.Size(525, 723);
			this.chart1.TabIndex = 6;
			this.chart1.Text = "chart1";
			// 
			// groupBox11
			// 
			this.groupBox11.Controls.Add(this.textBox_DCState);
			this.groupBox11.Controls.Add(this.textBox_DCInV);
			this.groupBox11.Controls.Add(this.textBox_DCTemp);
			this.groupBox11.Controls.Add(this.textBox_DCOutV);
			this.groupBox11.Controls.Add(this.textBox_DCOutC);
			this.groupBox11.Controls.Add(this.label47);
			this.groupBox11.Controls.Add(this.label46);
			this.groupBox11.Controls.Add(this.label45);
			this.groupBox11.Controls.Add(this.label_ST);
			this.groupBox11.Controls.Add(this.label_InOV);
			this.groupBox11.Controls.Add(this.label_COT);
			this.groupBox11.Controls.Add(this.label_FE);
			this.groupBox11.Controls.Add(this.label_OutLV);
			this.groupBox11.Controls.Add(this.label_OutSC);
			this.groupBox11.Controls.Add(this.label_OutOV);
			this.groupBox11.Controls.Add(this.label_InLV);
			this.groupBox11.Controls.Add(this.label_OutOC);
			this.groupBox11.Controls.Add(this.label_OT);
			this.groupBox11.Controls.Add(this.label44);
			this.groupBox11.Controls.Add(this.label52);
			this.groupBox11.Controls.Add(this.label51);
			this.groupBox11.Controls.Add(this.label50);
			this.groupBox11.Controls.Add(this.label49);
			this.groupBox11.Controls.Add(this.label48);
			this.groupBox11.Controls.Add(this.label43);
			this.groupBox11.Controls.Add(this.label42);
			this.groupBox11.Controls.Add(this.label41);
			this.groupBox11.Controls.Add(this.label19);
			this.groupBox11.Controls.Add(this.label17);
			this.groupBox11.Controls.Add(this.label13);
			this.groupBox11.Location = new System.Drawing.Point(12, 650);
			this.groupBox11.Name = "groupBox11";
			this.groupBox11.Size = new System.Drawing.Size(853, 138);
			this.groupBox11.TabIndex = 7;
			this.groupBox11.TabStop = false;
			this.groupBox11.Text = "DC-DC";
			// 
			// textBox_DCState
			// 
			this.textBox_DCState.Location = new System.Drawing.Point(90, 93);
			this.textBox_DCState.Name = "textBox_DCState";
			this.textBox_DCState.ReadOnly = true;
			this.textBox_DCState.Size = new System.Drawing.Size(91, 25);
			this.textBox_DCState.TabIndex = 1;
			this.textBox_DCState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_DCInV
			// 
			this.textBox_DCInV.Location = new System.Drawing.Point(772, 93);
			this.textBox_DCInV.Name = "textBox_DCInV";
			this.textBox_DCInV.ReadOnly = true;
			this.textBox_DCInV.Size = new System.Drawing.Size(63, 25);
			this.textBox_DCInV.TabIndex = 1;
			this.textBox_DCInV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_DCTemp
			// 
			this.textBox_DCTemp.Location = new System.Drawing.Point(609, 93);
			this.textBox_DCTemp.Name = "textBox_DCTemp";
			this.textBox_DCTemp.ReadOnly = true;
			this.textBox_DCTemp.Size = new System.Drawing.Size(63, 25);
			this.textBox_DCTemp.TabIndex = 1;
			this.textBox_DCTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_DCOutV
			// 
			this.textBox_DCOutV.Location = new System.Drawing.Point(454, 93);
			this.textBox_DCOutV.Name = "textBox_DCOutV";
			this.textBox_DCOutV.ReadOnly = true;
			this.textBox_DCOutV.Size = new System.Drawing.Size(63, 25);
			this.textBox_DCOutV.TabIndex = 1;
			this.textBox_DCOutV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_DCOutC
			// 
			this.textBox_DCOutC.Location = new System.Drawing.Point(294, 93);
			this.textBox_DCOutC.Name = "textBox_DCOutC";
			this.textBox_DCOutC.ReadOnly = true;
			this.textBox_DCOutC.Size = new System.Drawing.Size(63, 25);
			this.textBox_DCOutC.TabIndex = 1;
			this.textBox_DCOutC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label47
			// 
			this.label47.AutoSize = true;
			this.label47.Location = new System.Drawing.Point(717, 61);
			this.label47.Name = "label47";
			this.label47.Size = new System.Drawing.Size(67, 15);
			this.label47.TabIndex = 0;
			this.label47.Text = "自检状态";
			// 
			// label46
			// 
			this.label46.AutoSize = true;
			this.label46.Location = new System.Drawing.Point(556, 61);
			this.label46.Name = "label46";
			this.label46.Size = new System.Drawing.Size(67, 15);
			this.label46.TabIndex = 0;
			this.label46.Text = "通讯超时";
			// 
			// label45
			// 
			this.label45.AutoSize = true;
			this.label45.Location = new System.Drawing.Point(383, 61);
			this.label45.Name = "label45";
			this.label45.Size = new System.Drawing.Size(67, 15);
			this.label45.TabIndex = 0;
			this.label45.Text = "硬件故障";
			// 
			// label_ST
			// 
			this.label_ST.AutoSize = true;
			this.label_ST.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_ST.ForeColor = System.Drawing.Color.DimGray;
			this.label_ST.Location = new System.Drawing.Point(784, 54);
			this.label_ST.Name = "label_ST";
			this.label_ST.Size = new System.Drawing.Size(40, 28);
			this.label_ST.TabIndex = 0;
			this.label_ST.Text = "●";
			// 
			// label_InOV
			// 
			this.label_InOV.AutoSize = true;
			this.label_InOV.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_InOV.ForeColor = System.Drawing.Color.DimGray;
			this.label_InOV.Location = new System.Drawing.Point(784, 20);
			this.label_InOV.Name = "label_InOV";
			this.label_InOV.Size = new System.Drawing.Size(40, 28);
			this.label_InOV.TabIndex = 0;
			this.label_InOV.Text = "●";
			// 
			// label_COT
			// 
			this.label_COT.AutoSize = true;
			this.label_COT.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_COT.ForeColor = System.Drawing.Color.DimGray;
			this.label_COT.Location = new System.Drawing.Point(622, 54);
			this.label_COT.Name = "label_COT";
			this.label_COT.Size = new System.Drawing.Size(40, 28);
			this.label_COT.TabIndex = 0;
			this.label_COT.Text = "●";
			// 
			// label_FE
			// 
			this.label_FE.AutoSize = true;
			this.label_FE.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_FE.ForeColor = System.Drawing.Color.DimGray;
			this.label_FE.Location = new System.Drawing.Point(449, 54);
			this.label_FE.Name = "label_FE";
			this.label_FE.Size = new System.Drawing.Size(40, 28);
			this.label_FE.TabIndex = 0;
			this.label_FE.Text = "●";
			// 
			// label_OutLV
			// 
			this.label_OutLV.AutoSize = true;
			this.label_OutLV.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_OutLV.ForeColor = System.Drawing.Color.DimGray;
			this.label_OutLV.Location = new System.Drawing.Point(622, 20);
			this.label_OutLV.Name = "label_OutLV";
			this.label_OutLV.Size = new System.Drawing.Size(40, 28);
			this.label_OutLV.TabIndex = 0;
			this.label_OutLV.Text = "●";
			// 
			// label_OutSC
			// 
			this.label_OutSC.AutoSize = true;
			this.label_OutSC.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_OutSC.ForeColor = System.Drawing.Color.DimGray;
			this.label_OutSC.Location = new System.Drawing.Point(259, 54);
			this.label_OutSC.Name = "label_OutSC";
			this.label_OutSC.Size = new System.Drawing.Size(40, 28);
			this.label_OutSC.TabIndex = 0;
			this.label_OutSC.Text = "●";
			// 
			// label_OutOV
			// 
			this.label_OutOV.AutoSize = true;
			this.label_OutOV.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_OutOV.ForeColor = System.Drawing.Color.DimGray;
			this.label_OutOV.Location = new System.Drawing.Point(449, 20);
			this.label_OutOV.Name = "label_OutOV";
			this.label_OutOV.Size = new System.Drawing.Size(40, 28);
			this.label_OutOV.TabIndex = 0;
			this.label_OutOV.Text = "●";
			// 
			// label_InLV
			// 
			this.label_InLV.AutoSize = true;
			this.label_InLV.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_InLV.ForeColor = System.Drawing.Color.DimGray;
			this.label_InLV.Location = new System.Drawing.Point(94, 54);
			this.label_InLV.Name = "label_InLV";
			this.label_InLV.Size = new System.Drawing.Size(40, 28);
			this.label_InLV.TabIndex = 0;
			this.label_InLV.Text = "●";
			// 
			// label_OutOC
			// 
			this.label_OutOC.AutoSize = true;
			this.label_OutOC.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_OutOC.ForeColor = System.Drawing.Color.DimGray;
			this.label_OutOC.Location = new System.Drawing.Point(259, 20);
			this.label_OutOC.Name = "label_OutOC";
			this.label_OutOC.Size = new System.Drawing.Size(40, 28);
			this.label_OutOC.TabIndex = 0;
			this.label_OutOC.Text = "●";
			// 
			// label_OT
			// 
			this.label_OT.AutoSize = true;
			this.label_OT.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label_OT.ForeColor = System.Drawing.Color.DimGray;
			this.label_OT.Location = new System.Drawing.Point(94, 20);
			this.label_OT.Name = "label_OT";
			this.label_OT.Size = new System.Drawing.Size(40, 28);
			this.label_OT.TabIndex = 0;
			this.label_OT.Text = "●";
			// 
			// label44
			// 
			this.label44.AutoSize = true;
			this.label44.Location = new System.Drawing.Point(193, 61);
			this.label44.Name = "label44";
			this.label44.Size = new System.Drawing.Size(67, 15);
			this.label44.TabIndex = 0;
			this.label44.Text = "输出短路";
			// 
			// label52
			// 
			this.label52.AutoSize = true;
			this.label52.Location = new System.Drawing.Point(702, 98);
			this.label52.Name = "label52";
			this.label52.Size = new System.Drawing.Size(67, 15);
			this.label52.TabIndex = 0;
			this.label52.Text = "输入电压";
			// 
			// label51
			// 
			this.label51.AutoSize = true;
			this.label51.Location = new System.Drawing.Point(543, 98);
			this.label51.Name = "label51";
			this.label51.Size = new System.Drawing.Size(67, 15);
			this.label51.TabIndex = 0;
			this.label51.Text = "工作温度";
			// 
			// label50
			// 
			this.label50.AutoSize = true;
			this.label50.Location = new System.Drawing.Point(383, 98);
			this.label50.Name = "label50";
			this.label50.Size = new System.Drawing.Size(67, 15);
			this.label50.TabIndex = 0;
			this.label50.Text = "输出电压";
			// 
			// label49
			// 
			this.label49.AutoSize = true;
			this.label49.Location = new System.Drawing.Point(224, 98);
			this.label49.Name = "label49";
			this.label49.Size = new System.Drawing.Size(67, 15);
			this.label49.TabIndex = 0;
			this.label49.Text = "输出电流";
			// 
			// label48
			// 
			this.label48.AutoSize = true;
			this.label48.Location = new System.Drawing.Point(17, 98);
			this.label48.Name = "label48";
			this.label48.Size = new System.Drawing.Size(67, 15);
			this.label48.TabIndex = 0;
			this.label48.Text = "工作状态";
			// 
			// label43
			// 
			this.label43.AutoSize = true;
			this.label43.Location = new System.Drawing.Point(28, 61);
			this.label43.Name = "label43";
			this.label43.Size = new System.Drawing.Size(67, 15);
			this.label43.TabIndex = 0;
			this.label43.Text = "输入欠压";
			// 
			// label42
			// 
			this.label42.AutoSize = true;
			this.label42.Location = new System.Drawing.Point(717, 27);
			this.label42.Name = "label42";
			this.label42.Size = new System.Drawing.Size(67, 15);
			this.label42.TabIndex = 0;
			this.label42.Text = "输入过压";
			// 
			// label41
			// 
			this.label41.AutoSize = true;
			this.label41.Location = new System.Drawing.Point(556, 27);
			this.label41.Name = "label41";
			this.label41.Size = new System.Drawing.Size(67, 15);
			this.label41.TabIndex = 0;
			this.label41.Text = "输出欠压";
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(383, 27);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(67, 15);
			this.label19.TabIndex = 0;
			this.label19.Text = "输出过压";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(193, 27);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(67, 15);
			this.label17.TabIndex = 0;
			this.label17.Text = "输出过流";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(28, 27);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(67, 15);
			this.label13.TabIndex = 0;
			this.label13.Text = "温度过高";
			// 
			// groupBox12
			// 
			this.groupBox12.Controls.Add(this.label60);
			this.groupBox12.Controls.Add(this.textBox_brakeinteval);
			this.groupBox12.Controls.Add(this.label59);
			this.groupBox12.Controls.Add(this.textBox_executedCounter);
			this.groupBox12.Controls.Add(this.textBox_totalCounter);
			this.groupBox12.Controls.Add(this.label54);
			this.groupBox12.Controls.Add(this.label10);
			this.groupBox12.Controls.Add(this.button_scheduled);
			this.groupBox12.Location = new System.Drawing.Point(520, 81);
			this.groupBox12.Name = "groupBox12";
			this.groupBox12.Size = new System.Drawing.Size(331, 100);
			this.groupBox12.TabIndex = 8;
			this.groupBox12.TabStop = false;
			this.groupBox12.Text = "定时任务";
			// 
			// label60
			// 
			this.label60.AutoSize = true;
			this.label60.Location = new System.Drawing.Point(289, 28);
			this.label60.Name = "label60";
			this.label60.Size = new System.Drawing.Size(15, 15);
			this.label60.TabIndex = 6;
			this.label60.Text = "s";
			// 
			// textBox_brakeinteval
			// 
			this.textBox_brakeinteval.Location = new System.Drawing.Point(226, 23);
			this.textBox_brakeinteval.Name = "textBox_brakeinteval";
			this.textBox_brakeinteval.Size = new System.Drawing.Size(63, 25);
			this.textBox_brakeinteval.TabIndex = 5;
			this.textBox_brakeinteval.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label59
			// 
			this.label59.AutoSize = true;
			this.label59.Location = new System.Drawing.Point(155, 29);
			this.label59.Name = "label59";
			this.label59.Size = new System.Drawing.Size(67, 15);
			this.label59.TabIndex = 4;
			this.label59.Text = "间隔时间";
			// 
			// textBox_executedCounter
			// 
			this.textBox_executedCounter.Location = new System.Drawing.Point(103, 61);
			this.textBox_executedCounter.Name = "textBox_executedCounter";
			this.textBox_executedCounter.ReadOnly = true;
			this.textBox_executedCounter.Size = new System.Drawing.Size(76, 25);
			this.textBox_executedCounter.TabIndex = 1;
			this.textBox_executedCounter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// textBox_totalCounter
			// 
			this.textBox_totalCounter.Location = new System.Drawing.Point(77, 23);
			this.textBox_totalCounter.Name = "textBox_totalCounter";
			this.textBox_totalCounter.Size = new System.Drawing.Size(52, 25);
			this.textBox_totalCounter.TabIndex = 1;
			this.textBox_totalCounter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label54
			// 
			this.label54.AutoSize = true;
			this.label54.Location = new System.Drawing.Point(12, 68);
			this.label54.Name = "label54";
			this.label54.Size = new System.Drawing.Size(82, 15);
			this.label54.TabIndex = 0;
			this.label54.Text = "已执行次数";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(12, 29);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(52, 15);
			this.label10.TabIndex = 0;
			this.label10.Text = "总次数";
			// 
			// button_scheduled
			// 
			this.button_scheduled.Location = new System.Drawing.Point(216, 61);
			this.button_scheduled.Name = "button_scheduled";
			this.button_scheduled.Size = new System.Drawing.Size(60, 27);
			this.button_scheduled.TabIndex = 3;
			this.button_scheduled.Text = "开始";
			this.button_scheduled.UseVisualStyleBackColor = true;
			this.button_scheduled.Click += new System.EventHandler(this.button_scheduled_Click);
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Location = new System.Drawing.Point(880, 9);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(524, 779);
			this.tabControl1.TabIndex = 9;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.chart1);
			this.tabPage1.Location = new System.Drawing.Point(4, 25);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(516, 750);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "波形";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.checkBox1);
			this.tabPage2.Controls.Add(this.button4);
			this.tabPage2.Controls.Add(this.button3);
			this.tabPage2.Controls.Add(this.richTextBox3);
			this.tabPage2.Controls.Add(this.button2);
			this.tabPage2.Controls.Add(this.label57);
			this.tabPage2.Controls.Add(this.richTextBox2);
			this.tabPage2.Controls.Add(this.label_framespeed);
			this.tabPage2.Controls.Add(this.label56);
			this.tabPage2.Controls.Add(this.button1);
			this.tabPage2.Controls.Add(this.label_frameCount);
			this.tabPage2.Controls.Add(this.label55);
			this.tabPage2.Controls.Add(this.richTextBox1);
			this.tabPage2.Controls.Add(this.listView1);
			this.tabPage2.Location = new System.Drawing.Point(4, 25);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(516, 750);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "数据";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// checkBox1
			// 
			this.checkBox1.AutoSize = true;
			this.checkBox1.Location = new System.Drawing.Point(292, 11);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(89, 19);
			this.checkBox1.TabIndex = 12;
			this.checkBox1.Text = "显示数据";
			this.checkBox1.UseVisualStyleBackColor = true;
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(62, 538);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(75, 23);
			this.button4.TabIndex = 11;
			this.button4.Text = "复制文本";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(363, 538);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(75, 27);
			this.button3.TabIndex = 10;
			this.button3.Text = "清除窗口";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// richTextBox3
			// 
			this.richTextBox3.Location = new System.Drawing.Point(16, 574);
			this.richTextBox3.Name = "richTextBox3";
			this.richTextBox3.Size = new System.Drawing.Size(478, 136);
			this.richTextBox3.TabIndex = 9;
			this.richTextBox3.Text = "";
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(403, 309);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 27);
			this.button2.TabIndex = 7;
			this.button2.Text = "清除窗口";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// label57
			// 
			this.label57.AutoSize = true;
			this.label57.Location = new System.Drawing.Point(32, 309);
			this.label57.Name = "label57";
			this.label57.Size = new System.Drawing.Size(82, 15);
			this.label57.TabIndex = 8;
			this.label57.Text = "发送窗口：";
			// 
			// richTextBox2
			// 
			this.richTextBox2.Location = new System.Drawing.Point(10, 345);
			this.richTextBox2.Name = "richTextBox2";
			this.richTextBox2.Size = new System.Drawing.Size(494, 181);
			this.richTextBox2.TabIndex = 7;
			this.richTextBox2.Text = "";
			// 
			// label_framespeed
			// 
			this.label_framespeed.AutoSize = true;
			this.label_framespeed.Location = new System.Drawing.Point(205, 13);
			this.label_framespeed.Name = "label_framespeed";
			this.label_framespeed.Size = new System.Drawing.Size(63, 15);
			this.label_framespeed.TabIndex = 6;
			this.label_framespeed.Text = "0.0 f/s";
			// 
			// label56
			// 
			this.label56.AutoSize = true;
			this.label56.Location = new System.Drawing.Point(157, 13);
			this.label56.Name = "label56";
			this.label56.Size = new System.Drawing.Size(52, 15);
			this.label56.TabIndex = 5;
			this.label56.Text = "帧率：";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(403, 7);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 27);
			this.button1.TabIndex = 4;
			this.button1.Text = "清除窗口";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label_frameCount
			// 
			this.label_frameCount.AutoSize = true;
			this.label_frameCount.Location = new System.Drawing.Point(91, 13);
			this.label_frameCount.Name = "label_frameCount";
			this.label_frameCount.Size = new System.Drawing.Size(15, 15);
			this.label_frameCount.TabIndex = 3;
			this.label_frameCount.Text = "0";
			// 
			// label55
			// 
			this.label55.AutoSize = true;
			this.label55.Location = new System.Drawing.Point(9, 13);
			this.label55.Name = "label55";
			this.label55.Size = new System.Drawing.Size(82, 15);
			this.label55.TabIndex = 2;
			this.label55.Text = "接收帧数：";
			// 
			// richTextBox1
			// 
			this.richTextBox1.Location = new System.Drawing.Point(16, 41);
			this.richTextBox1.MaxLength = 100;
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new System.Drawing.Size(478, 246);
			this.richTextBox1.TabIndex = 1;
			this.richTextBox1.Text = "";
			// 
			// listView1
			// 
			this.listView1.Location = new System.Drawing.Point(-7, 300);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(587, 231);
			this.listView1.TabIndex = 0;
			this.listView1.UseCompatibleStateImageBehavior = false;
			this.listView1.View = System.Windows.Forms.View.Details;
			this.listView1.Visible = false;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(1415, 800);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.groupBox12);
			this.Controls.Add(this.groupBox11);
			this.Controls.Add(this.groupBox6);
			this.Controls.Add(this.groupBox4);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "刹车试验台架 V0.98";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.groupBox4.ResumeLayout(false);
			this.groupBox10.ResumeLayout(false);
			this.groupBox10.PerformLayout();
			this.groupBox7.ResumeLayout(false);
			this.groupBox7.PerformLayout();
			this.groupBox5.ResumeLayout(false);
			this.groupBox5.PerformLayout();
			this.groupBox9.ResumeLayout(false);
			this.groupBox9.PerformLayout();
			this.groupBox8.ResumeLayout(false);
			this.groupBox8.PerformLayout();
			this.groupBox6.ResumeLayout(false);
			this.groupBox6.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
			this.groupBox11.ResumeLayout(false);
			this.groupBox11.PerformLayout();
			this.groupBox12.ResumeLayout(false);
			this.groupBox12.PerformLayout();
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.tabPage2.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBox_CANID;
		private System.Windows.Forms.TextBox textBox_pulse_1;
		private System.Windows.Forms.TextBox textBox_pulse_2;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.TextBox textBox_wheel_pressure;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox textBox_master_pressure;
		private System.Windows.Forms.Button button_release;
		private System.Windows.Forms.Button button_brake;
		private System.Windows.Forms.ComboBox comboBox_serialport;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Button button_settorque;
		private System.Windows.Forms.Button button_setspeed;
		private System.Windows.Forms.TextBox textBox_targettorque;
		private System.Windows.Forms.TextBox textBox_targetspeed;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label_HVReady;
		private System.Windows.Forms.Label label_motorenable;
		private System.Windows.Forms.Label label_HVOK;
		private System.Windows.Forms.TextBox textBox_IdCurrent;
		private System.Windows.Forms.Label label_InitDone;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox_BusCurrent;
		private System.Windows.Forms.TextBox textBox_IqCurrent;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.ComboBox comboBox_frametype;
		private System.Windows.Forms.GroupBox groupBox10;
		private System.Windows.Forms.TextBox textBox_faultcode1;
		private System.Windows.Forms.TextBox textBox_faultcode4;
		private System.Windows.Forms.TextBox textBox_faultcode3;
		private System.Windows.Forms.Label label36;
		private System.Windows.Forms.TextBox textBox_faultcode2;
		private System.Windows.Forms.Label label37;
		private System.Windows.Forms.Label label38;
		private System.Windows.Forms.Label label39;
		private System.Windows.Forms.Label label40;
		private System.Windows.Forms.GroupBox groupBox9;
		private System.Windows.Forms.TextBox textBox_motortemp;
		private System.Windows.Forms.TextBox textBox_FirmwareVersion;
		private System.Windows.Forms.TextBox textBox_coldOiltemp;
		private System.Windows.Forms.TextBox textBox_IGBTtemp;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.TextBox textBox_controllertemp;
		private System.Windows.Forms.Label label32;
		private System.Windows.Forms.Label label33;
		private System.Windows.Forms.Label label34;
		private System.Windows.Forms.Label label35;
		private System.Windows.Forms.GroupBox groupBox8;
		private System.Windows.Forms.TextBox textBox_PhaseCurrent;
		private System.Windows.Forms.TextBox textBox_BusVoltage;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.GroupBox groupBox7;
		private System.Windows.Forms.TextBox textBox_MaxSpeedAtCurTor;
		private System.Windows.Forms.TextBox textBox_torqueback;
		private System.Windows.Forms.TextBox textBox_MaxNegTorque;
		private System.Windows.Forms.TextBox textBox_MaxPosTorque;
		private System.Windows.Forms.TextBox textBox_speedback;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.TextBox textBox_faultlevel;
		private System.Windows.Forms.TextBox textBox_motormode;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.TextBox textBox_motorstate;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label_torquevalid;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label_speedvalid;
		private System.Windows.Forms.GroupBox groupBox6;
		private System.Windows.Forms.Button button_serial;
		private System.IO.Ports.SerialPort serialPort1;
		private System.Windows.Forms.Button button_enableDem;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.TextBox textBox_BrkPedl;
		private System.Windows.Forms.Button button_BrkPedl;
		private System.Windows.Forms.TextBox textBox_DCDCID;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
		private System.Windows.Forms.GroupBox groupBox11;
		private System.Windows.Forms.TextBox textBox_DCState;
		private System.Windows.Forms.TextBox textBox_DCInV;
		private System.Windows.Forms.TextBox textBox_DCTemp;
		private System.Windows.Forms.TextBox textBox_DCOutV;
		private System.Windows.Forms.TextBox textBox_DCOutC;
		private System.Windows.Forms.Label label47;
		private System.Windows.Forms.Label label46;
		private System.Windows.Forms.Label label45;
		private System.Windows.Forms.Label label_ST;
		private System.Windows.Forms.Label label_InOV;
		private System.Windows.Forms.Label label_COT;
		private System.Windows.Forms.Label label_FE;
		private System.Windows.Forms.Label label_OutLV;
		private System.Windows.Forms.Label label_OutSC;
		private System.Windows.Forms.Label label_OutOV;
		private System.Windows.Forms.Label label_InLV;
		private System.Windows.Forms.Label label_OutOC;
		private System.Windows.Forms.Label label_OT;
		private System.Windows.Forms.Label label44;
		private System.Windows.Forms.Label label52;
		private System.Windows.Forms.Label label51;
		private System.Windows.Forms.Label label50;
		private System.Windows.Forms.Label label49;
		private System.Windows.Forms.Label label48;
		private System.Windows.Forms.Label label43;
		private System.Windows.Forms.Label label42;
		private System.Windows.Forms.Label label41;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label13;
		private System.ComponentModel.BackgroundWorker backgroundWorker1;
		private System.Windows.Forms.Button button_OilDrainage;
		private System.Windows.Forms.Label label53;
		private System.Windows.Forms.GroupBox groupBox12;
		private System.Windows.Forms.TextBox textBox_executedCounter;
		private System.Windows.Forms.TextBox textBox_totalCounter;
		private System.Windows.Forms.Label label54;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Button button_scheduled;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.Label label_frameCount;
		private System.Windows.Forms.Label label55;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label_framespeed;
		private System.Windows.Forms.Label label56;
		private System.Windows.Forms.Label label57;
		private System.Windows.Forms.RichTextBox richTextBox2;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button_disableDem;
		private System.Windows.Forms.RichTextBox richTextBox3;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Label label58;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.TextBox textBox_brakeinteval;
		private System.Windows.Forms.Label label59;
		private System.Windows.Forms.Label label60;
		private System.Windows.Forms.Label label_OilDutyCycleBack;
		private System.Windows.Forms.Button button_setOilPumpCycle;
		private System.Windows.Forms.TextBox textBox_OilPumpDutycycle;
		private System.Windows.Forms.Button button_setOilPumpCycle2;
		private System.Windows.Forms.TextBox textBox_OilPumpDutycycle2;
	}
}

