#pragma once
extern "C"	_declspec(dllexport)	int __stdcall test01(int a, int b, int c);
extern "C"	_declspec(dllexport)	int __stdcall test02(int a, int b);
